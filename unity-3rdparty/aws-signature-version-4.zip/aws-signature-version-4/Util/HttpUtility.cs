﻿using System;
using System.Collections.Specialized;
using System.Linq;
using System.Net;
using System.Text;

namespace AwsSignatureVersion4.Util
{
    public class HttpQSCollection : NameValueCollection
    {
        public override string ToString()
        {
            int count = Count;
            if (count == 0)
                return "";
            StringBuilder sb = new StringBuilder();
            string[] keys = AllKeys;
            for (int i = 0; i < count; i++)
            {
                sb.AppendFormat("{0}={1}&", keys[i], WebUtility.UrlEncode(this[keys[i]]));
            }
            if (sb.Length > 0)
                sb.Length--;
            return sb.ToString();
        }
    }

    public class HttpUtility
    {
        public static HttpQSCollection ParseQueryString(string query)
        {
            if (1 < query.Split('?').Length)
            {
                query = query.Split('?')[1];
            }
            if (true == String.IsNullOrEmpty(query))
            {
                return new HttpQSCollection();
            }

            var paramDictionary = query.Split('&').Select(p => p.Split('='))
                                                 .ToDictionary(nameval => nameval[0],
                                                               nameval => nameval.Length > 1
                                                                    ? nameval[1] : "");

            return paramDictionary.Aggregate(new HttpQSCollection(),
                (seed, current) =>
                {
                    seed.Add(current.Key, current.Value);
                    return seed;
                });
        }
    }
}
