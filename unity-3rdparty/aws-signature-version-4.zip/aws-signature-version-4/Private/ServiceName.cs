﻿namespace AwsSignatureVersion4.Private
{
    internal static class ServiceName
    {
        internal const string S3 = "s3";
    }
}
