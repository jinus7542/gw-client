﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AWSSignatureV4_S3_Sample
{
    class Program
    {
        private static string bucketName = "mybucketname";
        private static string awsRegion = "us-west-2";

        static void Main(string[] args)
        {
            Console.WriteLine("************************************************");
            PutS3ObjectSample.Run(awsRegion, 
                                  bucketName, 
                                  "MySampleFile.txt");

            Console.WriteLine("\n\n************************************************");
            PutS3ObjectChunkedSample.Run(awsRegion, 
                                         bucketName, 
                                         "MySampleFileChunked.txt");

            Console.WriteLine("\n\n************************************************");
            GetS3ObjectSample.Run(awsRegion, 
                                  bucketName, 
                                  "MySampleFile.txt");

            Console.WriteLine("\n\n************************************************");
            PresignedUrlSample.Run(awsRegion, 
                                   bucketName, 
                                   "MySampleFile.txt");
        }
    }
}
